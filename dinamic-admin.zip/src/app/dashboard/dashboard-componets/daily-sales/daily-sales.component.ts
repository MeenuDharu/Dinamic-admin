import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-daily-sales',
  templateUrl: './daily-sales.component.html',
  styleUrls: ['./daily-sales.component.css']
})
export class DailySalesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
