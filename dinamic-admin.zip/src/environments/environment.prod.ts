export const environment = {
  production: true,
  ws_url: 'https://dinamic.io/mobileapi'
};